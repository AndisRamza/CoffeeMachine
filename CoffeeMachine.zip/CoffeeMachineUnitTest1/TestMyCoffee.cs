﻿using CoffeeMachineLib2;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace CoffeeMachineUnitTest1
{
    [TestClass]
    public class TestMyCoffee
    {
        [TestMethod]
        public void BuyCoffee_ResultTrue()
        {
            var coffeeMachine = new CoffeMachine();
            coffeeMachine.SetMoneyDeposit(200m);
            var expectedResult = true;
            var actualResult = coffeeMachine.BuyACoffee(1, CoffeeSize.Large);
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void GetMoney_SetCorrectAmountOfMoney_ReturnCorrectAmountOfMoney()
        {
            var coffeeMachine = new CoffeMachine();
            decimal deposit = 200m;
            coffeeMachine.SetMoneyDeposit(deposit);
            var expectedResult = deposit;
            var actualResult = coffeeMachine.GetMoneyDeposit();
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void GetMoney_SetZeroAmountOfMoney_ReturnZeroAmountOfMoney()
        {
            var coffeeMachine = new CoffeMachine();
            var deposit = 0;
            coffeeMachine.SetMoneyDeposit(deposit);
            var expectedResult = deposit;
            var actualResult = coffeeMachine.GetMoneyDeposit();
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void BuyCoffee_IfDepositZero_ResultFalse()
        {
            var coffeeMachine = new CoffeMachine();
            coffeeMachine.SetMoneyDeposit(0);
            var expectedResult = false;
            var actualResult = coffeeMachine.BuyACoffee(1, CoffeeSize.Large);
            Assert.AreEqual(expectedResult, actualResult);
        }


        [TestMethod]
        public void BuyCoffee_IfDepositNotSet_ResultFalse()
        {
            var coffeeMachine = new CoffeMachine();
            var expectedResult = false;
            var actualResult = coffeeMachine.BuyACoffee(1, CoffeeSize.Large);
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void SetMoneyDeposit_IfMoneyValueIsIncorrect_ResultInvalidAmountOfMoney()
        {
            var coffeeMachine = new CoffeMachine();

            Assert.ThrowsException<InvalidAmountOfMoney>(() => coffeeMachine.SetMoneyDeposit(0));
        }
    }
}
