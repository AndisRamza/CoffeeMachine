﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMachineLib2
{
    public class Coffee
    {
        private int _id;
        private string _name;
        private decimal _price;
        private CoffeeType _type;

        public Coffee(int id, string name, decimal price, CoffeeType type)
        {
            _id = id;
            _name = name;
            _price = price;
            _type = type;
        }

        public int GetId()
        {
            return _id;
        }

        public decimal GetPrice()
        {
            return _price;
        }
    }
}
