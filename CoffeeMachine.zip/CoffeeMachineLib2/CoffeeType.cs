﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMachineLib2
{
    public enum CoffeeType
    {
        None = -1,
        Black = 0,
        White = 1
    }
}
