﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMachineLib2
{
    public class InvalidAmountOfMoney : Exception
    {
        public InvalidAmountOfMoney() : base() { }
        public InvalidAmountOfMoney(string message) : base(message) { }
        public InvalidAmountOfMoney(string message, Exception inner) : base(message, inner) { }
    }
}
