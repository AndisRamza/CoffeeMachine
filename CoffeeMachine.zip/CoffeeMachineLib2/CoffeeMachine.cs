﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CoffeeMachineLib2
{
    public class CoffeMachine
    {
        private decimal _moneyDeposit = 0m;
        private Coffee _choosedCoffee;
        private CoffeeSize _choosedCoffeSize;
        private decimal _totalCost;

        private List<Coffee> _coffeMenu = new List<Coffee>() { 
        new Coffee(1,"Krapalik",1.2m,CoffeeType.Black),
        new Coffee(2,"BigBang",2.6m,CoffeeType.White),
        new Coffee(3,"SuperDuper",3.6m,CoffeeType.White),
        new Coffee(4,"HugeDrink",5.2m,CoffeeType.Black),
        };

        public bool BuyACoffee(int coffeeId, CoffeeSize coffeeSize)
        {
            SelectCoffee(coffeeId);
            SelectSize(coffeeSize);
            _totalCost = CalculateTotalCost(coffeeSize);

            if (isEnoughMoney())
            {
                _moneyDeposit -= _totalCost;
                return true;
            } else
            {
                return false;
            }

        }

        public void SelectCoffee(int id)
        {
            _choosedCoffee = _coffeMenu.Where(coffe => coffe.GetId() == id).First();
        }

        public void SelectSize(CoffeeSize coffeSize) 
        {
            _choosedCoffeSize = coffeSize;
        }

        public bool isEnoughMoney()
        {
            return (_totalCost <= _moneyDeposit) ? true : false;
        }

        public decimal CalculateTotalCost(CoffeeSize size)
        {
            decimal extraCostBySize;
            switch (size) {
                case CoffeeSize.Small:
                    extraCostBySize = 0.2m;
                    return _choosedCoffee.GetPrice() + extraCostBySize;
                case CoffeeSize.Medium:
                    extraCostBySize = 0.4m;
                    return _choosedCoffee.GetPrice() + extraCostBySize;
                case CoffeeSize.Large:
                    extraCostBySize = 0.6m;
                    return _choosedCoffee.GetPrice() + extraCostBySize;
                case CoffeeSize.ExtraLarge:
                    extraCostBySize = 0.8m;
                    return _choosedCoffee.GetPrice() + extraCostBySize;
                default:
                    return _choosedCoffee.GetPrice();
            }
        }
        public void SetMoneyDeposit(decimal money)
        {

            if (money <= 0.0m) throw new InvalidAmountOfMoney("Incorrect amount of money");
            _moneyDeposit = money;
        }

        public decimal GetMoneyDeposit()
        {
            return _moneyDeposit;
        }



    }
}