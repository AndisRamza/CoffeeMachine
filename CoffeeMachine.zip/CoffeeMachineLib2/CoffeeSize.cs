﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeMachineLib2
{
    public enum CoffeeSize
    {
        None = -1,
        Small = 0,
        Medium = 1,
        Large = 2,
        ExtraLarge = 3
    }
}
